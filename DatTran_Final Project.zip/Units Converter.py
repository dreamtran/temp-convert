'''
      Program name: Units Converter.py
            Author: Dat Tran
Last date modified: 05/08/2023

This program convert between different units of measurement such as
length, weight, time, data, area and temperature.
'''


# Import Module
from tkinter import *
from tkinter import messagebox

# Create UC_main window
UC_main = Tk()

# Title for main window
UC_main.title("Units Converter")
# Set Width x Height
UC_main.geometry('370x450')
# Disable resizeable
UC_main.resizable(False, False)


def open_window1():     # Length window

    length_main = Toplevel(UC_main)
    length_main.resizable(False, False)     # Disable resizeable
    length_main.title("  Units Converter - Length  ")   # Title of the window

    label = Label(length_main, text="      Units Converter - Length      ", font=("Arial", 15))
    label.grid(row=0)

    # Create frame for whole window
    row1 = Frame(length_main)
    row1.grid(row=1)
    row1.columnconfigure(0, weight=3)
    row1.columnconfigure(1, weight=1)
    row1.columnconfigure(2, weight=2)

    # Create labels using grid
    label1 = Label(row1, text="From: ")
    label1.grid(column=0, row=0, sticky=W)
    label2 = Label(row1, text="To:")
    label2.grid(column=0, row=1, sticky=W)

    # Create entries using grid
    entry1 = Entry(row1, width=20)
    entry2 = Entry(row1, width=20)
    entry1.grid(column=1, row=0, sticky=W)
    entry2.grid(column=1, row=1, sticky=W)

    # Option menu
    options = ["Millimeter", "Centimeter", "Decimeter",
               "Meter", "Kilometer", "Inch", "Foot", "Yard", "Mile"]

    selected_option = StringVar()
    selected_option.set(options[0])
    option_menu = OptionMenu(row1, selected_option, *options)
    option_menu.grid(column=2, row=0, sticky=E)

    selected_option1 = StringVar()
    selected_option1.set(options[0])
    option_menu = OptionMenu(row1, selected_option1, *options)
    option_menu.grid(column=2, row=1, sticky=E)

    # Close window function
    def call_back():
        length_main.destroy()

    # Convert function
    # Get input from option menus and entries
    # Then use conversions formulas to convert input
    def convert():
        from_unit = selected_option.get()
        to_unit = selected_option1.get()

        # Conversion formulas
        conversions = {
            "Millimeter": {"Millimeter": 1, "Centimeter": 0.1, "Decimeter": 0.01, "Meter": 0.001, "Kilometer": 0.000001,
                           "Inch": 0.03937, "Foot": 0.003281, "Yard": 0.001094, "Mile": 0.0000006214},
            "Centimeter": {"Millimeter": 10, "Centimeter": 1, "Decimeter": 0.1, "Meter": 0.01, "Kilometer": 0.00001,
                           "Inch": 0.3937, "Foot": 0.03281, "Yard": 0.01094, "Mile": 0.000006214},
            "Decimeter": {"Millimeter": 100, "Centimeter": 10, "Decimeter": 1, "Meter": 0.1, "Kilometer": 0.0001,
                          "Inch": 3.937, "Foot": 0.3281, "Yard": 0.1094, "Mile": 0.00006214},
            "Meter": {"Millimeter": 1000, "Centimeter": 100, "Decimeter": 10, "Meter": 1, "Kilometer": 0.001,
                      "Inch": 39.37, "Foot": 3.281, "Yard": 1.094, "Mile": 0.0006214},
            "Kilometer": {"Millimeter": 1000000, "Centimeter": 100000, "Decimeter": 10000, "Meter": 1000,
                          "Kilometer": 1, "Inch": 39370, "Foot": 3281, "Yard": 1094, "Mile": 0.6214},
            "Inch": {"Millimeter": 25.4, "Centimeter": 2.54, "Decimeter": 0.254, "Meter": 0.0254,
                     "Kilometer": 0.0000254, "Inch": 1, "Foot": 0.08333, "Yard": 0.02778, "Mile": 0.00001578},
            "Foot": {"Millimeter": 304.8, "Centimeter": 30.48, "Decimeter": 3.048, "Meter": 0.3048,
                     "Kilometer": 0.0003048, "Inch": 12, "Foot": 1, "Yard": 0.3333, "Mile": 0.0001894},
            "Yard": {"Millimeter": 914.4, "Centimeter": 91.44, "Decimeter": 9.144, "Meter": 0.9144,
                     "Kilometer": 0.0009144, "Inch": 36, "Foot": 3, "Yard": 1, "Mile": 0.0005682},
            "Mile": {"Millimeter": 1609344, "Centimeter": 160934.4, "Decimeter": 16093.44, "Meter": 1609.344,
                     "Kilometer": 1.609344, "Inch": 63360, "Foot": 5280, "Yard": 1760}
        }

        # Input validation
        try:
            from_value = float(entry1.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number in the 'From' field")
            return

        # Check if the 'From' field is empty
        if not entry1.get():
            messagebox.showerror("Error", "Please enter a value in the 'From' field")
            return

        # Convert using dict
        to_value = from_value * conversions[from_unit][to_unit]
        to_value = "{:.2f}".format(to_value)
        entry2.delete(0, END)
        entry2.insert(0, str(to_value))

    # Convert button
    convert_button = Button(length_main, text="Convert", command=convert)
    convert_button.grid(row=2)

    # Close window button
    back_button = Button(length_main, text="Back", command=call_back)
    back_button.grid(row=3, pady=2)

    length_main.mainloop()


def open_window2():     # Weight Window
    weight_main = Toplevel(UC_main)
    weight_main.resizable(False, False)     # Disable resizeable
    weight_main.title("  Units Converter - Weight  ")   # Title

    label = Label(weight_main, text="      Units Converter - Weight      ", font=("Arial", 15))
    label.grid(row=0)

    # Create frame for window
    row1 = Frame(weight_main)
    row1.grid(row=1)
    row1.columnconfigure(0, weight=3)
    row1.columnconfigure(1, weight=1)
    row1.columnconfigure(2, weight=2)

    # Create labels using grid
    label1 = Label(row1, text="From: ")
    label1.grid(column=0, row=0, sticky=W)
    label2 = Label(row1, text="To:")
    label2.grid(column=0, row=1, sticky=W)

    # Create entries using grid
    entry1 = Entry(row1, width=20)
    entry2 = Entry(row1, width=20)
    entry1.grid(column=1, row=0, sticky=W)
    entry2.grid(column=1, row=1, sticky=W)

    # Option menu
    options = ["Milligram", "Gram", "Kilogram", "Pound", "Ounce"]

    selected_option = StringVar()
    selected_option.set(options[0])
    option_menu = OptionMenu(row1, selected_option, *options)
    option_menu.grid(column=2, row=0, sticky=E)

    selected_option1 = StringVar()
    selected_option1.set(options[0])
    option_menu = OptionMenu(row1, selected_option1, *options)
    option_menu.grid(column=2, row=1, sticky=E)

    # Convert function
    # Get input from option menus and entries
    # Then use conversions formulas to convert input
    def convert():
        from_unit = selected_option.get()
        to_unit = selected_option1.get()

        # Conversions using dict
        conversions = {
            "Milligram": {"Milligram": 1, "Gram": 0.001, "Kilogram": 0.000001, "Pound": 0.00000220462,
                          "Ounce": 0.000035274},
            "Gram": {"Milligram": 1000, "Gram": 1, "Kilogram": 0.001, "Pound": 0.00220462, "Ounce": 0.035274},
            "Kilogram": {"Milligram": 1000000, "Gram": 1000, "Kilogram": 1, "Pound": 2.20462, "Ounce": 35.274},
            "Pound": {"Milligram": 453592, "Gram": 453.592, "Kilogram": 0.453592, "Pound": 1, "Ounce": 16},
            "Ounce": {"Milligram": 28349.5, "Gram": 28.3495, "Kilogram": 0.0283495, "Pound": 0.0625, "Ounce": 1}
        }

        # Input validation
        try:
            from_value = float(entry1.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number in the 'From' field")
            return

            # Check if the 'From' field is empty
        if not entry1.get():
            messagebox.showerror("Error", "Please enter a value in the 'From' field")
            return

        # Converting
        to_value = from_value * conversions[from_unit][to_unit]
        to_value = "{:.2f}".format(to_value)
        entry2.delete(0, END)
        entry2.insert(0, str(to_value))

    # Close window function
    def call_back():
        weight_main.destroy()

    # Convert button
    convert_button = Button(weight_main, text="Convert", command=convert)
    convert_button.grid(row=2)

    # Close window button
    back_button = Button(weight_main, text="Back", command=call_back)
    back_button.grid(row=3, pady=2)

    weight_main.mainloop()


def open_window3():     # Area window
    area_main = Toplevel(UC_main)
    area_main.resizable(False, False)   # Disable resizeable
    area_main.title("      Units Converter - Area      ")   # Title of the window

    label = Label(area_main, text="      Units Converter - Area      ", font=("Arial", 15))
    label.grid(row=0)

    # Create frame for the whole window
    row1 = Frame(area_main)
    row1.grid(row=1)
    row1.columnconfigure(0, weight=3)
    row1.columnconfigure(1, weight=1)
    row1.columnconfigure(2, weight=2)

    # Create labels
    label1 = Label(row1, text="From: ")
    label1.grid(column=0, row=0, sticky=W)
    label2 = Label(row1, text="To:")
    label2.grid(column=0, row=1, sticky=W)

    # Create entries
    entry1 = Entry(row1, width=20)
    entry2 = Entry(row1, width=20)
    entry1.grid(column=1, row=0, sticky=W)
    entry2.grid(column=1, row=1, sticky=W)

    # Option menu
    options = ["Square Kilometer", "Square Meter", "Square Centimeter", "Square Mile", "Acre",
               "Square Feet", "Square Inch"]

    selected_option = StringVar()
    selected_option.set(options[0])
    option_menu = OptionMenu(row1, selected_option, *options)
    option_menu.grid(column=2, row=0, sticky=E)

    selected_option1 = StringVar()
    selected_option1.set(options[0])
    option_menu = OptionMenu(row1, selected_option1, *options)
    option_menu.grid(column=2, row=1, sticky=E)

    # Close window function
    def call_back():
        area_main.destroy()

    # Convert function
    # Get input from option menus and entries
    # Then use conversions formulas to convert input
    def convert():
        from_unit = selected_option.get()
        to_unit = selected_option1.get()

        conversions = {
            "Square Kilometer": {
                "Square Meter": 1000000,
                "Square Centimeter": 10000000000,
                "Square Mile": 0.386102,
                "Acre": 247.105,
                "Square Feet": 10763910,
                "Square Inch": 1550003100,
            },
            "Square Meter": {
                "Square Kilometer": 0.000001,
                "Square Centimeter": 10000,
                "Square Mile": 0.000000386102,
                "Acre": 0.000247105,
                "Square Feet": 10.763910,
                "Square Inch": 1550.003100,
            },
            "Square Centimeter": {
                "Square Kilometer": 0.00000001,
                "Square Meter": 0.0001,
                "Square Mile": 0.000000000386102,
                "Acre": 0.000000247105,
                "Square Feet": 0.0010763910,
                "Square Inch": 0.1550003100,
            },
            "Square Mile": {
                "Square Kilometer": 2.58999,
                "Square Meter": 2589988.11,
                "Square Centimeter": 25899881103.36,
                "Acre": 640,
                "Square Feet": 27878400,
                "Square Inch": 4014489600,
            },
            "Acre": {
                "Square Kilometer": 0.00404686,
                "Square Meter": 4046.86,
                "Square Centimeter": 40468600,
                "Square Mile": 0.0015625,
                "Square Feet": 43560,
                "Square Inch": 6272640,
            },
            "Square Feet": {
                "Square Kilometer": 0.00000009290304,
                "Square Meter": 0.09290304,
                "Square Centimeter": 929.0304,
                "Square Mile": 0.00000003587006,
                "Acre": 0.00002295684,
                "Square Inch": 144,
            },
            "Square Inch": {
                "Square Kilometer": 0.00000000064516,
                "Square Meter": 0.00064516,
                "Square Centimeter": 6.4516,
                "Square Mile": 0.000000000249097,
                "Acre": 0.0000001594225,
                "Square Feet": 0.00694444,
            },
        }

        # Input validation
        try:
            from_value = float(entry1.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number in the 'From' field")
            return

            # check if the 'From' field is empty
        if not entry1.get():
            messagebox.showerror("Error", "Please enter a value in the 'From' field")
            return

        # Converting
        to_value = from_value * conversions[from_unit][to_unit]
        to_value = "{:.2f}".format(to_value)
        entry2.delete(0, END)
        entry2.insert(0, str(to_value))

    # Convert button
    convert_button = Button(area_main, text="Convert", command=convert)
    convert_button.grid(row=2)

    # Close window button
    back_button = Button(area_main, text="Back", command=call_back)
    back_button.grid(row=3, pady=2)

    area_main.mainloop()
    
    
def open_window4():     # Data window
    data_main = Toplevel(UC_main)
    data_main.resizable(False, False)   # Disable resizeable
    data_main.title("      Units Converter - Data      ")   # Title of the window

    label = Label(data_main, text="      Units Converter - Data      ", font=("Arial", 15))
    label.grid(row=0)

    # Create frame for whole window
    row1 = Frame(data_main)
    row1.grid(row=1)
    row1.columnconfigure(0, weight=3)
    row1.columnconfigure(1, weight=1)
    row1.columnconfigure(2, weight=2)

    # Create labels
    label1 = Label(row1, text="From: ")
    label1.grid(column=0, row=0, sticky=W)
    label2 = Label(row1, text="To:")
    label2.grid(column=0, row=1, sticky=W)

    # Create entries
    entry1 = Entry(row1, width=20)
    entry2 = Entry(row1, width=20)
    entry1.grid(column=1, row=0, sticky=W)
    entry2.grid(column=1, row=1, sticky=W)

    # Option menu
    options = ["Bit", "Byte", "Kilobyte", "Megabyte", "Terabyte"]

    selected_option = StringVar()
    selected_option.set(options[0])
    option_menu = OptionMenu(row1, selected_option, *options)
    option_menu.grid(column=2, row=0, sticky=E)

    selected_option1 = StringVar()
    selected_option1.set(options[0])
    option_menu = OptionMenu(row1, selected_option1, *options)
    option_menu.grid(column=2, row=1, sticky=E)

    # Close window function
    def call_back():
        data_main.destroy()

    # Convert function
    # Get input from option menus and entries
    # Then use conversions formulas to convert input
    def convert():
        from_unit = selected_option.get()
        to_unit = selected_option1.get()

        conversions = {
            "Bit": {
                "Bit": 1,
                "Byte": 0.125,
                "Kilobyte": 0.00012207,
                "Megabyte": 1.1921e-7,
                "Terabyte": 1.1642e-10
            },
            "Byte": {
                "Bit": 8,
                "Byte": 1,
                "Kilobyte": 0.00097656,
                "Megabyte": 9.5367e-7,
                "Terabyte": 9.3132e-10
            },
            "Kilobyte": {
                "Bit": 8192,
                "Byte": 1024,
                "Kilobyte": 1,
                "Megabyte": 0.00097656,
                "Terabyte": 9.5367e-7
            },
            "Megabyte": {
                "Bit": 8.389e+6,
                "Byte": 1.049e+6,
                "Kilobyte": 1024,
                "Megabyte": 1,
                "Terabyte": 0.00097656
            },
            "Terabyte": {
                "Bit": 8.796e+9,
                "Byte": 1.1e+9,
                "Kilobyte": 1.074e+6,
                "Megabyte": 1048.576,
                "Terabyte": 1
            }
        }

        # Input validation
        try:
            from_value = float(entry1.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number in the 'From' field")
            return

            # check if the 'From' field is empty
        if not entry1.get():
            messagebox.showerror("Error", "Please enter a value in the 'From' field")
            return

        # Converting
        to_value = from_value * conversions[from_unit][to_unit]
        to_value = "{:.2f}".format(to_value)
        entry2.delete(0, END)
        entry2.insert(0, str(to_value))

    # Convert button
    convert_button = Button(data_main, text="Convert", command=convert)
    convert_button.grid(row=2)

    # Close window button
    back_button = Button(data_main, text="Back", command=call_back)
    back_button.grid(row=3, pady=2)

    data_main.mainloop()
    
    
def open_window5():     # Time window
    time_main = Toplevel(UC_main)
    time_main.resizable(False, False)   # Disable resizeable
    time_main.title("      Units Converter - Time      ")   # Title of the window

    label = Label(time_main, text="      Units Converter - Time      ", font=("Arial", 15))
    label.grid(row=0)

    # Create frame for window
    row1 = Frame(time_main)
    row1.grid(row=1)
    row1.columnconfigure(0, weight=3)
    row1.columnconfigure(1, weight=1)
    row1.columnconfigure(2, weight=2)

    # Create labels
    label1 = Label(row1, text="From: ")
    label1.grid(column=0, row=0, sticky=W)
    label2 = Label(row1, text="To:")
    label2.grid(column=0, row=1, sticky=W)

    # Create entries
    entry1 = Entry(row1, width=20)
    entry2 = Entry(row1, width=20)
    entry1.grid(column=1, row=0, sticky=W)
    entry2.grid(column=1, row=1, sticky=W)

    # Option menu
    options = ["Second", "Minute", "Hour", "Day", "Week", "Month", "Year"]

    selected_option = StringVar()
    selected_option.set(options[0])
    option_menu = OptionMenu(row1, selected_option, *options)
    option_menu.grid(column=2, row=0, sticky=E)

    selected_option1 = StringVar()
    selected_option1.set(options[0])
    option_menu = OptionMenu(row1, selected_option1, *options)
    option_menu.grid(column=2, row=1, sticky=E)

    # Close window function
    def call_back():
        time_main.destroy()

    # Convert function
    # Get input from option menus and entries
    # Then use conversions formulas to convert input
    def convert():
        from_unit = selected_option.get()
        to_unit = selected_option1.get()

        # conversion formulas
        conversions = {
            "Hour": {"Hour": 1, "Minute": 60, "Second": 3600, "Day": 1 / 24, "Week": 1 / 168, 
                     "Month": 1 / 720, "Year": 1 / 8760},
            "Minute": {"Minute": 1, "Hour": 1 / 60, "Second": 60, "Day": 1 / 1440, "Week": 1 / 10080, 
                       "Month": 1 / 43200,
                       "Year": 1 / 525600},
            "Second": {"Second": 1, "Hour": 1 / 3600, "Minute": 1 / 60, "Day": 1 / 86400, "Week": 1 / 604800, 
                       "Month": 1 / 2592000,
                       "Year": 1 / 31536000},
            "Day": {"Day": 1, "Hour": 24, "Minute": 1440, "Second": 86400, "Week": 1 / 7, "Month": 1 / 30.44, 
                    "Year": 1 / 365},
            "Week": {"Week": 1, "Hour": 168, "Minute": 10080, "Second": 604800, "Day": 7, "Month": 1 / 4.345,
                     "Year": 1 / 52.143},
            "Month": {"Month": 1, "Hour": 720, "Minute": 43200, "Second": 2592000, "Day": 30.44, "Week": 4.345, 
                      "Year": 1 / 12},
            "Year": {"Year": 1, "Hour": 8760, "Minute": 525600, "Second": 31536000, "Day": 365, "Week": 52.143, 
                     "Month": 12}
        }

        # Input validation
        try:
            from_value = float(entry1.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number in the 'From' field")
            return

            # Check if the 'From' field is empty
        if not entry1.get():
            messagebox.showerror("Error", "Please enter a value in the 'From' field")
            return

        to_value = from_value * conversions[from_unit][to_unit]
        to_value = "{:.2f}".format(to_value)
        entry2.delete(0, END)
        entry2.insert(0, str(to_value))

    # Convert button
    convert_button = Button(time_main, text="Convert", command=convert)
    convert_button.grid(row=2)

    # Close window button
    back_button = Button(time_main, text="Back", command=call_back)
    back_button.grid(row=3, pady=2)

    time_main.mainloop()
    
    
def open_window6():     # Temperature window
    temp_main = Toplevel(UC_main)
    temp_main.resizable(False, False)   # Disable resize window
    temp_main.title("  Units Converter - Temperature  ")    # Title of window

    label = Label(temp_main, text="  Units Converter - Temperature  ", font=("Arial", 15))
    label.grid(row=0)

    row1 = Frame(temp_main)
    row1.grid(row=1)
    row1.columnconfigure(0, weight=3)
    row1.columnconfigure(1, weight=1)
    row1.columnconfigure(2, weight=2)

    # Create labels
    label1 = Label(row1, text="From: ")
    label1.grid(column=0, row=0, sticky=W)
    label2 = Label(row1, text="To:")
    label2.grid(column=0, row=1, sticky=W)

    # Create entries
    entry1 = Entry(row1, width=20)
    entry2 = Entry(row1, width=20)
    entry1.grid(column=1, row=0, sticky=W)
    entry2.grid(column=1, row=1, sticky=W)

    # Create option menu
    options = ["Fahrenheit", "Celsius"]

    selected_option = StringVar()
    selected_option.set(options[0])
    option_menu = OptionMenu(row1, selected_option, *options)
    option_menu.grid(column=2, row=0, sticky=E)

    selected_option1 = StringVar()
    selected_option1.set(options[0])
    option_menu = OptionMenu(row1, selected_option1, *options)
    option_menu.grid(column=2, row=1, sticky=E)

    # Close window function
    def call_back():
        temp_main.destroy()

    # Convert function
    # Get input from option menus and entries
    # Then use conversions formulas to convert input
    def convert():
        from_unit = selected_option.get()
        to_unit = selected_option1.get()

        # Input validation
        try:
            from_value = float(entry1.get())
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number in the 'From' field")
            return

            # Check if the 'From' field is empty
        if not entry1.get():
            messagebox.showerror("Error", "Please enter a value in the 'From' field")
            return

        if from_unit == "Celsius" and to_unit == "Fahrenheit":
            f = from_value * 9 / 5 + 32
            f = "{:.2f}".format(f)
            entry2.delete(0, END)
            entry2.insert(0, str(f))
        elif from_unit == "Fahrenheit" and to_unit == "Celsius":
            c = (from_value - 32) * 5 / 9
            c = "{:.2f}".format(c)
            entry2.delete(0, END)
            entry2.insert(0, str(c))
        elif from_unit == "Celsius" and to_unit == "Celsius":
            entry2.delete(0, END)
            entry2.insert(0, str(entry1.get()))
        elif from_unit == "Fahrenheit" and to_unit == "Fahrenheit":
            entry2.delete(0, END)
            entry2.insert(0, str(entry1.get()))

    # Convert button
    convert_button = Button(temp_main, text="Convert", command=convert)
    convert_button.grid(row=2)

    # Close window button
    back_button = Button(temp_main, text="Back", command=call_back)
    back_button.grid(row=3, pady=2)

    temp_main.mainloop()


# Import images
area = PhotoImage(file='area.png')
data = PhotoImage(file='data.png')
length = PhotoImage(file='length.png')
temp = PhotoImage(file='temp.png')
time = PhotoImage(file='time.png')
weight = PhotoImage(file='weight.png')

# Resize images
area = area.subsample(2)
data = data.subsample(2)
length = length.subsample(2)
temp = temp.subsample(2)
time = time.subsample(2)
weight = weight.subsample(2)

# Create frame for main window
frame1 = Frame(UC_main, width=600, height=200)
frame2 = Frame(UC_main, width=600, height=200)
frame3 = Frame(UC_main, width=600, height=200)
frame4 = Frame(UC_main, width=600, height=200)
frame1.grid(row=0, column=0)
frame2.grid(row=1, column=0)
frame3.grid(row=2, column=0)
frame4.grid(row=3, column=0)

# Create buttons with names and images
button1 = Button(frame2, text='Length', image=length,
                 command=open_window1, borderwidth=0, compound=TOP)
button2 = Button(frame2, text='Weight', image=weight,
                 command=open_window2, borderwidth=0, compound=TOP)
button3 = Button(frame2, text='Area', image=area,
                 command=open_window3, borderwidth=0, compound=TOP)
button4 = Button(frame3, text='Data', image=data,
                 command=open_window4, borderwidth=0, compound=TOP)
button5 = Button(frame3, text='Time', image=time,
                 command=open_window5, borderwidth=0, compound=TOP)
button6 = Button(frame3, text='Temperature', image=temp,
                 command=open_window6, borderwidth=0, compound=TOP)

button1.grid(row=0, column=1, padx=5, pady=5)
button2.grid(row=0, column=2, padx=5, pady=5)
button3.grid(row=0, column=3, padx=5, pady=5)
button4.grid(row=0, column=0, padx=5, pady=5)
button5.grid(row=0, column=1, padx=5, pady=5)
button6.grid(row=0, column=2, padx=5, pady=5)

# Text label for main window
label_main = Label(frame1, text="Units Converter", font=("Arial", 35))
label_main.grid(row=0, padx=20, pady=20)


def exit_app():     # Close function for main window
    UC_main.destroy()


# Close button
exit_button = Button(frame4, text="Exit", command=exit_app)
exit_button.grid(pady=20)

# execute main window
UC_main.mainloop()
